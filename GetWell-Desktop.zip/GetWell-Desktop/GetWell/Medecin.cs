﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GetWell
{
    public static class Medecin
    {
        public static int Id_doc { get; set; }
        public static string Username { get; set; }
        public static string Nom { get; set; }
        public static string Prenom { get; set; }
        public static string Tel { get; set; }
        public static byte[] Image { get; set; }
        public static string Email { get; set; }
        public static int Nbrpatients { get; set; }
        public static string ville { get; set; }
        public static string Adresse { get; set; }
        public static string Facebook { get; set; }
        public static string Whatsapp { get; set; }
        public static string Instagram { get; set; }
        public static string Twitter { get; set; }
        public static string Linkeden { get; set; }
        public static double latitude { get; set; }
        public static double longitude { get; set; }


    }
}
