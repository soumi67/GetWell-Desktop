﻿
namespace GetWell
{
    partial class UpdateInfo_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UpdateInfo_Form));
            this.siticoneElipse1 = new Siticone.UI.WinForms.SiticoneElipse(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.siticoneSeparator1 = new Siticone.UI.WinForms.SiticoneSeparator();
            this.siticoneSeparator2 = new Siticone.UI.WinForms.SiticoneSeparator();
            this.siticoneSeparator3 = new Siticone.UI.WinForms.SiticoneSeparator();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.siticoneVSeparator1 = new Siticone.UI.WinForms.SiticoneVSeparator();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btn_Minimize = new System.Windows.Forms.Button();
            this.btn_Exit = new System.Windows.Forms.Button();
            this.btn_save = new Siticone.UI.WinForms.SiticoneButton();
            this.siticoneButton3 = new Siticone.UI.WinForms.SiticoneButton();
            this.siticoneButton1 = new Siticone.UI.WinForms.SiticoneButton();
            this.txt_instagram = new Siticone.UI.WinForms.SiticoneMaterialTextBox();
            this.txt_twitter = new Siticone.UI.WinForms.SiticoneMaterialTextBox();
            this.txt_linkeden = new Siticone.UI.WinForms.SiticoneMaterialTextBox();
            this.txt_whatsapp = new Siticone.UI.WinForms.SiticoneMaterialTextBox();
            this.txt_facebook = new Siticone.UI.WinForms.SiticoneMaterialTextBox();
            this.txt_tel = new Siticone.UI.WinForms.SiticoneMaterialTextBox();
            this.txt_adresse = new Siticone.UI.WinForms.SiticoneMaterialTextBox();
            this.txt_ville = new Siticone.UI.WinForms.SiticoneMaterialTextBox();
            this.txt_email = new Siticone.UI.WinForms.SiticoneMaterialTextBox();
            this.txt_username = new Siticone.UI.WinForms.SiticoneMaterialTextBox();
            this.text_nom = new Siticone.UI.WinForms.SiticoneMaterialTextBox();
            this.txt_prenom = new Siticone.UI.WinForms.SiticoneMaterialTextBox();
            this.SuspendLayout();
            // 
            // siticoneElipse1
            // 
            this.siticoneElipse1.BorderRadius = 30;
            this.siticoneElipse1.TargetControl = this;
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(83, 81);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(582, 15);
            this.panel1.TabIndex = 14;
            // 
            // siticoneSeparator1
            // 
            this.siticoneSeparator1.Location = new System.Drawing.Point(83, 119);
            this.siticoneSeparator1.Name = "siticoneSeparator1";
            this.siticoneSeparator1.Size = new System.Drawing.Size(226, 10);
            this.siticoneSeparator1.TabIndex = 16;
            // 
            // siticoneSeparator2
            // 
            this.siticoneSeparator2.Location = new System.Drawing.Point(439, 119);
            this.siticoneSeparator2.Name = "siticoneSeparator2";
            this.siticoneSeparator2.Size = new System.Drawing.Size(226, 10);
            this.siticoneSeparator2.TabIndex = 16;
            // 
            // siticoneSeparator3
            // 
            this.siticoneSeparator3.Location = new System.Drawing.Point(439, 519);
            this.siticoneSeparator3.Name = "siticoneSeparator3";
            this.siticoneSeparator3.Size = new System.Drawing.Size(226, 10);
            this.siticoneSeparator3.TabIndex = 16;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Bell MT", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.label1.Location = new System.Drawing.Point(153, 112);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(86, 24);
            this.label1.TabIndex = 17;
            this.label1.Text = " Général ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Bell MT", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.label2.Location = new System.Drawing.Point(478, 112);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(149, 24);
            this.label2.TabIndex = 17;
            this.label2.Text = " Médias Sociaux ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Bell MT", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.label3.Location = new System.Drawing.Point(491, 512);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(122, 24);
            this.label3.TabIndex = 17;
            this.label3.Text = " Localisation ";
            // 
            // siticoneVSeparator1
            // 
            this.siticoneVSeparator1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.siticoneVSeparator1.Location = new System.Drawing.Point(369, 140);
            this.siticoneVSeparator1.Name = "siticoneVSeparator1";
            this.siticoneVSeparator1.Size = new System.Drawing.Size(10, 441);
            this.siticoneVSeparator1.TabIndex = 20;
            // 
            // panel2
            // 
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(749, 42);
            this.panel2.TabIndex = 21;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            this.panel2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Panel_MouseDown);
            // 
            // btn_Minimize
            // 
            this.btn_Minimize.BackgroundImage = global::GetWell.Properties.Resources.appbar_minus;
            this.btn_Minimize.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_Minimize.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Minimize.FlatAppearance.BorderSize = 0;
            this.btn_Minimize.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btn_Minimize.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btn_Minimize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Minimize.Location = new System.Drawing.Point(671, 12);
            this.btn_Minimize.Name = "btn_Minimize";
            this.btn_Minimize.Size = new System.Drawing.Size(30, 30);
            this.btn_Minimize.TabIndex = 18;
            this.btn_Minimize.UseVisualStyleBackColor = true;
            this.btn_Minimize.Click += new System.EventHandler(this.btn_Minimize_Click);
            // 
            // btn_Exit
            // 
            this.btn_Exit.BackgroundImage = global::GetWell.Properties.Resources.appbar_close;
            this.btn_Exit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_Exit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Exit.FlatAppearance.BorderSize = 0;
            this.btn_Exit.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btn_Exit.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btn_Exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Exit.Location = new System.Drawing.Point(707, 12);
            this.btn_Exit.Name = "btn_Exit";
            this.btn_Exit.Size = new System.Drawing.Size(30, 30);
            this.btn_Exit.TabIndex = 19;
            this.btn_Exit.UseVisualStyleBackColor = true;
            this.btn_Exit.Click += new System.EventHandler(this.btn_Exit_Click);
            // 
            // btn_save
            // 
            this.btn_save.CheckedState.Parent = this.btn_save;
            this.btn_save.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_save.CustomImages.Parent = this.btn_save;
            this.btn_save.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(87)))), ((int)(((byte)(159)))));
            this.btn_save.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.btn_save.ForeColor = System.Drawing.Color.White;
            this.btn_save.HoveredState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(139)))), ((int)(((byte)(184)))));
            this.btn_save.HoveredState.Parent = this.btn_save;
            this.btn_save.Image = global::GetWell.Properties.Resources.appbar_check;
            this.btn_save.ImageOffset = new System.Drawing.Point(-10, 0);
            this.btn_save.ImageSize = new System.Drawing.Size(34, 34);
            this.btn_save.Location = new System.Drawing.Point(83, 646);
            this.btn_save.Name = "btn_save";
            this.btn_save.ShadowDecoration.Parent = this.btn_save;
            this.btn_save.Size = new System.Drawing.Size(582, 45);
            this.btn_save.TabIndex = 13;
            this.btn_save.Text = "Enregistrer les Modifications";
            this.btn_save.TextOffset = new System.Drawing.Point(-12, 0);
            this.btn_save.Click += new System.EventHandler(this.btn_save_Click);
            // 
            // siticoneButton3
            // 
            this.siticoneButton3.BorderRadius = 22;
            this.siticoneButton3.CheckedState.Parent = this.siticoneButton3;
            this.siticoneButton3.CustomImages.Parent = this.siticoneButton3;
            this.siticoneButton3.FillColor = System.Drawing.Color.Transparent;
            this.siticoneButton3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.siticoneButton3.ForeColor = System.Drawing.Color.White;
            this.siticoneButton3.HoveredState.Parent = this.siticoneButton3;
            this.siticoneButton3.Image = global::GetWell.Properties.Resources.Logo3;
            this.siticoneButton3.ImageSize = new System.Drawing.Size(200, 200);
            this.siticoneButton3.Location = new System.Drawing.Point(282, 33);
            this.siticoneButton3.Name = "siticoneButton3";
            this.siticoneButton3.ShadowDecoration.Parent = this.siticoneButton3;
            this.siticoneButton3.Size = new System.Drawing.Size(184, 52);
            this.siticoneButton3.TabIndex = 13;
            this.siticoneButton3.Click += new System.EventHandler(this.siticoneButton3_Click);
            // 
            // siticoneButton1
            // 
            this.siticoneButton1.CheckedState.Parent = this.siticoneButton1;
            this.siticoneButton1.CustomImages.Parent = this.siticoneButton1;
            this.siticoneButton1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.siticoneButton1.ForeColor = System.Drawing.Color.White;
            this.siticoneButton1.HoveredState.Parent = this.siticoneButton1;
            this.siticoneButton1.Image = global::GetWell.Properties.Resources.appbar_map_location;
            this.siticoneButton1.ImageSize = new System.Drawing.Size(40, 40);
            this.siticoneButton1.Location = new System.Drawing.Point(439, 558);
            this.siticoneButton1.Name = "siticoneButton1";
            this.siticoneButton1.ShadowDecoration.Parent = this.siticoneButton1;
            this.siticoneButton1.Size = new System.Drawing.Size(226, 39);
            this.siticoneButton1.TabIndex = 12;
            this.siticoneButton1.Text = "Modifier votre localisation";
            this.siticoneButton1.Click += new System.EventHandler(this.siticoneButton1_Click);
            // 
            // txt_instagram
            // 
            this.txt_instagram.Animated = false;
            this.txt_instagram.BorderThickness = 2;
            this.txt_instagram.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_instagram.DefaultText = "";
            this.txt_instagram.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_instagram.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_instagram.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_instagram.DisabledState.Parent = this.txt_instagram;
            this.txt_instagram.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_instagram.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(47)))), ((int)(((byte)(50)))));
            this.txt_instagram.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(172)))), ((int)(((byte)(17)))));
            this.txt_instagram.FocusedState.Parent = this.txt_instagram;
            this.txt_instagram.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.txt_instagram.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txt_instagram.HoveredState.BorderColor = System.Drawing.Color.LightSkyBlue;
            this.txt_instagram.HoveredState.Parent = this.txt_instagram;
            this.txt_instagram.IconLeft = global::GetWell.Properties.Resources.instagram;
            this.txt_instagram.Location = new System.Drawing.Point(439, 422);
            this.txt_instagram.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txt_instagram.Name = "txt_instagram";
            this.txt_instagram.PasswordChar = '\0';
            this.txt_instagram.PlaceholderText = "Instagram URL";
            this.txt_instagram.SelectedText = "";
            this.txt_instagram.ShadowDecoration.Parent = this.txt_instagram;
            this.txt_instagram.Size = new System.Drawing.Size(226, 39);
            this.txt_instagram.TabIndex = 11;
            this.txt_instagram.TextOffset = new System.Drawing.Point(5, 0);
            this.txt_instagram.TextChanged += new System.EventHandler(this.txt_confNewPass_TextChanged);
            // 
            // txt_twitter
            // 
            this.txt_twitter.Animated = false;
            this.txt_twitter.BorderThickness = 2;
            this.txt_twitter.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_twitter.DefaultText = "";
            this.txt_twitter.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_twitter.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_twitter.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_twitter.DisabledState.Parent = this.txt_twitter;
            this.txt_twitter.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_twitter.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(47)))), ((int)(((byte)(50)))));
            this.txt_twitter.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(172)))), ((int)(((byte)(17)))));
            this.txt_twitter.FocusedState.Parent = this.txt_twitter;
            this.txt_twitter.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.txt_twitter.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txt_twitter.HoveredState.BorderColor = System.Drawing.Color.LightSkyBlue;
            this.txt_twitter.HoveredState.Parent = this.txt_twitter;
            this.txt_twitter.IconLeft = global::GetWell.Properties.Resources.appbar_social_twitter;
            this.txt_twitter.IconLeftOffset = new System.Drawing.Point(-10, 0);
            this.txt_twitter.IconLeftSize = new System.Drawing.Size(35, 35);
            this.txt_twitter.Location = new System.Drawing.Point(439, 354);
            this.txt_twitter.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txt_twitter.Name = "txt_twitter";
            this.txt_twitter.PasswordChar = '\0';
            this.txt_twitter.PlaceholderText = "Twitter URL";
            this.txt_twitter.SelectedText = "";
            this.txt_twitter.ShadowDecoration.Parent = this.txt_twitter;
            this.txt_twitter.Size = new System.Drawing.Size(226, 39);
            this.txt_twitter.TabIndex = 10;
            this.txt_twitter.TextChanged += new System.EventHandler(this.txt_confNewPass_TextChanged);
            // 
            // txt_linkeden
            // 
            this.txt_linkeden.Animated = false;
            this.txt_linkeden.BorderThickness = 2;
            this.txt_linkeden.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_linkeden.DefaultText = "";
            this.txt_linkeden.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_linkeden.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_linkeden.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_linkeden.DisabledState.Parent = this.txt_linkeden;
            this.txt_linkeden.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_linkeden.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(47)))), ((int)(((byte)(50)))));
            this.txt_linkeden.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(172)))), ((int)(((byte)(17)))));
            this.txt_linkeden.FocusedState.Parent = this.txt_linkeden;
            this.txt_linkeden.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.txt_linkeden.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txt_linkeden.HoveredState.BorderColor = System.Drawing.Color.LightSkyBlue;
            this.txt_linkeden.HoveredState.Parent = this.txt_linkeden;
            this.txt_linkeden.IconLeft = global::GetWell.Properties.Resources.appbar_social_linkedin_variant;
            this.txt_linkeden.IconLeftOffset = new System.Drawing.Point(-10, 0);
            this.txt_linkeden.IconLeftSize = new System.Drawing.Size(35, 35);
            this.txt_linkeden.Location = new System.Drawing.Point(439, 286);
            this.txt_linkeden.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txt_linkeden.Name = "txt_linkeden";
            this.txt_linkeden.PasswordChar = '\0';
            this.txt_linkeden.PlaceholderText = "Linkeden URL";
            this.txt_linkeden.SelectedText = "";
            this.txt_linkeden.ShadowDecoration.Parent = this.txt_linkeden;
            this.txt_linkeden.Size = new System.Drawing.Size(226, 39);
            this.txt_linkeden.TabIndex = 9;
            this.txt_linkeden.TextChanged += new System.EventHandler(this.txt_confNewPass_TextChanged);
            // 
            // txt_whatsapp
            // 
            this.txt_whatsapp.Animated = false;
            this.txt_whatsapp.BorderThickness = 2;
            this.txt_whatsapp.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_whatsapp.DefaultText = "";
            this.txt_whatsapp.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_whatsapp.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_whatsapp.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_whatsapp.DisabledState.Parent = this.txt_whatsapp;
            this.txt_whatsapp.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_whatsapp.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(47)))), ((int)(((byte)(50)))));
            this.txt_whatsapp.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(172)))), ((int)(((byte)(17)))));
            this.txt_whatsapp.FocusedState.Parent = this.txt_whatsapp;
            this.txt_whatsapp.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.txt_whatsapp.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txt_whatsapp.HoveredState.BorderColor = System.Drawing.Color.LightSkyBlue;
            this.txt_whatsapp.HoveredState.Parent = this.txt_whatsapp;
            this.txt_whatsapp.IconLeft = global::GetWell.Properties.Resources.appbar_social_whatsapp;
            this.txt_whatsapp.IconLeftOffset = new System.Drawing.Point(-10, 0);
            this.txt_whatsapp.IconLeftSize = new System.Drawing.Size(35, 35);
            this.txt_whatsapp.Location = new System.Drawing.Point(439, 218);
            this.txt_whatsapp.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txt_whatsapp.Name = "txt_whatsapp";
            this.txt_whatsapp.PasswordChar = '\0';
            this.txt_whatsapp.PlaceholderText = "Num Whatsapp";
            this.txt_whatsapp.SelectedText = "";
            this.txt_whatsapp.ShadowDecoration.Parent = this.txt_whatsapp;
            this.txt_whatsapp.Size = new System.Drawing.Size(226, 39);
            this.txt_whatsapp.TabIndex = 8;
            this.txt_whatsapp.TextChanged += new System.EventHandler(this.txt_confNewPass_TextChanged);
            // 
            // txt_facebook
            // 
            this.txt_facebook.Animated = false;
            this.txt_facebook.BorderThickness = 2;
            this.txt_facebook.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_facebook.DefaultText = "";
            this.txt_facebook.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_facebook.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_facebook.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_facebook.DisabledState.Parent = this.txt_facebook;
            this.txt_facebook.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_facebook.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(47)))), ((int)(((byte)(50)))));
            this.txt_facebook.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(172)))), ((int)(((byte)(17)))));
            this.txt_facebook.FocusedState.Parent = this.txt_facebook;
            this.txt_facebook.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.txt_facebook.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txt_facebook.HoveredState.BorderColor = System.Drawing.Color.LightSkyBlue;
            this.txt_facebook.HoveredState.Parent = this.txt_facebook;
            this.txt_facebook.IconLeft = global::GetWell.Properties.Resources.appbar_social_facebook_variant;
            this.txt_facebook.IconLeftOffset = new System.Drawing.Point(-10, 0);
            this.txt_facebook.IconLeftSize = new System.Drawing.Size(35, 35);
            this.txt_facebook.Location = new System.Drawing.Point(439, 150);
            this.txt_facebook.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txt_facebook.Name = "txt_facebook";
            this.txt_facebook.PasswordChar = '\0';
            this.txt_facebook.PlaceholderText = "Facebook URL";
            this.txt_facebook.SelectedText = "";
            this.txt_facebook.ShadowDecoration.Parent = this.txt_facebook;
            this.txt_facebook.Size = new System.Drawing.Size(226, 39);
            this.txt_facebook.TabIndex = 7;
            this.txt_facebook.TextChanged += new System.EventHandler(this.txt_confNewPass_TextChanged);
            // 
            // txt_tel
            // 
            this.txt_tel.Animated = false;
            this.txt_tel.BorderThickness = 2;
            this.txt_tel.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_tel.DefaultText = "";
            this.txt_tel.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_tel.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_tel.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_tel.DisabledState.Parent = this.txt_tel;
            this.txt_tel.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_tel.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(47)))), ((int)(((byte)(50)))));
            this.txt_tel.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(172)))), ((int)(((byte)(17)))));
            this.txt_tel.FocusedState.Parent = this.txt_tel;
            this.txt_tel.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.txt_tel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txt_tel.HoveredState.BorderColor = System.Drawing.Color.LightSkyBlue;
            this.txt_tel.HoveredState.Parent = this.txt_tel;
            this.txt_tel.IconLeft = global::GetWell.Properties.Resources.appbar_phone;
            this.txt_tel.IconLeftOffset = new System.Drawing.Point(-10, 0);
            this.txt_tel.IconLeftSize = new System.Drawing.Size(35, 35);
            this.txt_tel.Location = new System.Drawing.Point(83, 354);
            this.txt_tel.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txt_tel.Name = "txt_tel";
            this.txt_tel.PasswordChar = '\0';
            this.txt_tel.PlaceholderText = "Telephone";
            this.txt_tel.SelectedText = "";
            this.txt_tel.ShadowDecoration.Parent = this.txt_tel;
            this.txt_tel.Size = new System.Drawing.Size(226, 39);
            this.txt_tel.TabIndex = 3;
            this.txt_tel.TextChanged += new System.EventHandler(this.txt_confNewPass_TextChanged);
            // 
            // txt_adresse
            // 
            this.txt_adresse.Animated = false;
            this.txt_adresse.BorderThickness = 2;
            this.txt_adresse.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_adresse.DefaultText = "";
            this.txt_adresse.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_adresse.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_adresse.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_adresse.DisabledState.Parent = this.txt_adresse;
            this.txt_adresse.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_adresse.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(47)))), ((int)(((byte)(50)))));
            this.txt_adresse.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(172)))), ((int)(((byte)(17)))));
            this.txt_adresse.FocusedState.Parent = this.txt_adresse;
            this.txt_adresse.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.txt_adresse.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txt_adresse.HoveredState.BorderColor = System.Drawing.Color.LightSkyBlue;
            this.txt_adresse.HoveredState.Parent = this.txt_adresse;
            this.txt_adresse.IconLeft = global::GetWell.Properties.Resources.appbar_location_checkin;
            this.txt_adresse.IconLeftOffset = new System.Drawing.Point(-10, 0);
            this.txt_adresse.IconLeftSize = new System.Drawing.Size(35, 35);
            this.txt_adresse.Location = new System.Drawing.Point(83, 558);
            this.txt_adresse.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txt_adresse.Name = "txt_adresse";
            this.txt_adresse.PasswordChar = '\0';
            this.txt_adresse.PlaceholderText = "Adresse";
            this.txt_adresse.SelectedText = "";
            this.txt_adresse.ShadowDecoration.Parent = this.txt_adresse;
            this.txt_adresse.Size = new System.Drawing.Size(226, 39);
            this.txt_adresse.TabIndex = 6;
            // 
            // txt_ville
            // 
            this.txt_ville.Animated = false;
            this.txt_ville.BorderThickness = 2;
            this.txt_ville.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_ville.DefaultText = "";
            this.txt_ville.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_ville.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_ville.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_ville.DisabledState.Parent = this.txt_ville;
            this.txt_ville.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_ville.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(47)))), ((int)(((byte)(50)))));
            this.txt_ville.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(172)))), ((int)(((byte)(17)))));
            this.txt_ville.FocusedState.Parent = this.txt_ville;
            this.txt_ville.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.txt_ville.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txt_ville.HoveredState.BorderColor = System.Drawing.Color.LightSkyBlue;
            this.txt_ville.HoveredState.Parent = this.txt_ville;
            this.txt_ville.IconLeft = global::GetWell.Properties.Resources.appbar_city;
            this.txt_ville.IconLeftOffset = new System.Drawing.Point(-10, 0);
            this.txt_ville.IconLeftSize = new System.Drawing.Size(35, 35);
            this.txt_ville.Location = new System.Drawing.Point(83, 490);
            this.txt_ville.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txt_ville.Name = "txt_ville";
            this.txt_ville.PasswordChar = '\0';
            this.txt_ville.PlaceholderText = "Ville";
            this.txt_ville.SelectedText = "";
            this.txt_ville.ShadowDecoration.Parent = this.txt_ville;
            this.txt_ville.Size = new System.Drawing.Size(226, 39);
            this.txt_ville.TabIndex = 5;
            // 
            // txt_email
            // 
            this.txt_email.Animated = false;
            this.txt_email.BorderThickness = 2;
            this.txt_email.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_email.DefaultText = "";
            this.txt_email.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_email.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_email.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_email.DisabledState.Parent = this.txt_email;
            this.txt_email.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_email.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(47)))), ((int)(((byte)(50)))));
            this.txt_email.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(172)))), ((int)(((byte)(17)))));
            this.txt_email.FocusedState.Parent = this.txt_email;
            this.txt_email.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.txt_email.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txt_email.HoveredState.BorderColor = System.Drawing.Color.LightSkyBlue;
            this.txt_email.HoveredState.Parent = this.txt_email;
            this.txt_email.IconLeft = global::GetWell.Properties.Resources.appbar_email1;
            this.txt_email.IconLeftOffset = new System.Drawing.Point(-10, 0);
            this.txt_email.IconLeftSize = new System.Drawing.Size(35, 35);
            this.txt_email.Location = new System.Drawing.Point(83, 422);
            this.txt_email.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txt_email.Name = "txt_email";
            this.txt_email.PasswordChar = '\0';
            this.txt_email.PlaceholderText = "Email";
            this.txt_email.SelectedText = "";
            this.txt_email.ShadowDecoration.Parent = this.txt_email;
            this.txt_email.Size = new System.Drawing.Size(226, 39);
            this.txt_email.TabIndex = 4;
            // 
            // txt_username
            // 
            this.txt_username.Animated = false;
            this.txt_username.BorderThickness = 2;
            this.txt_username.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_username.DefaultText = "";
            this.txt_username.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_username.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_username.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_username.DisabledState.Parent = this.txt_username;
            this.txt_username.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_username.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(47)))), ((int)(((byte)(50)))));
            this.txt_username.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(172)))), ((int)(((byte)(17)))));
            this.txt_username.FocusedState.Parent = this.txt_username;
            this.txt_username.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.txt_username.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txt_username.HoveredState.BorderColor = System.Drawing.Color.LightSkyBlue;
            this.txt_username.HoveredState.Parent = this.txt_username;
            this.txt_username.IconLeft = global::GetWell.Properties.Resources.user21;
            this.txt_username.Location = new System.Drawing.Point(83, 150);
            this.txt_username.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txt_username.Name = "txt_username";
            this.txt_username.PasswordChar = '\0';
            this.txt_username.PlaceholderForeColor = System.Drawing.Color.Gray;
            this.txt_username.PlaceholderText = "Nom d\'utilisateur";
            this.txt_username.SelectedText = "";
            this.txt_username.ShadowDecoration.Parent = this.txt_username;
            this.txt_username.Size = new System.Drawing.Size(226, 39);
            this.txt_username.TabIndex = 0;
            this.txt_username.TextOffset = new System.Drawing.Point(5, 0);
            // 
            // text_nom
            // 
            this.text_nom.Animated = false;
            this.text_nom.BorderThickness = 2;
            this.text_nom.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.text_nom.DefaultText = "";
            this.text_nom.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.text_nom.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.text_nom.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.text_nom.DisabledState.Parent = this.text_nom;
            this.text_nom.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.text_nom.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(47)))), ((int)(((byte)(50)))));
            this.text_nom.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(172)))), ((int)(((byte)(17)))));
            this.text_nom.FocusedState.Parent = this.text_nom;
            this.text_nom.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.text_nom.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.text_nom.HoveredState.BorderColor = System.Drawing.Color.LightSkyBlue;
            this.text_nom.HoveredState.Parent = this.text_nom;
            this.text_nom.IconLeft = global::GetWell.Properties.Resources.user21;
            this.text_nom.Location = new System.Drawing.Point(83, 218);
            this.text_nom.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.text_nom.Name = "text_nom";
            this.text_nom.PasswordChar = '\0';
            this.text_nom.PlaceholderText = "Nom";
            this.text_nom.SelectedText = "";
            this.text_nom.ShadowDecoration.Parent = this.text_nom;
            this.text_nom.Size = new System.Drawing.Size(226, 39);
            this.text_nom.TabIndex = 1;
            this.text_nom.TextOffset = new System.Drawing.Point(5, 0);
            // 
            // txt_prenom
            // 
            this.txt_prenom.Animated = false;
            this.txt_prenom.BorderThickness = 2;
            this.txt_prenom.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_prenom.DefaultText = "";
            this.txt_prenom.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_prenom.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_prenom.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_prenom.DisabledState.Parent = this.txt_prenom;
            this.txt_prenom.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_prenom.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(47)))), ((int)(((byte)(50)))));
            this.txt_prenom.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(172)))), ((int)(((byte)(17)))));
            this.txt_prenom.FocusedState.Parent = this.txt_prenom;
            this.txt_prenom.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.txt_prenom.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txt_prenom.HoveredState.BorderColor = System.Drawing.Color.LightSkyBlue;
            this.txt_prenom.HoveredState.Parent = this.txt_prenom;
            this.txt_prenom.IconLeft = global::GetWell.Properties.Resources.user21;
            this.txt_prenom.Location = new System.Drawing.Point(83, 286);
            this.txt_prenom.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txt_prenom.Name = "txt_prenom";
            this.txt_prenom.PasswordChar = '\0';
            this.txt_prenom.PlaceholderText = "Prenom";
            this.txt_prenom.SelectedText = "";
            this.txt_prenom.ShadowDecoration.Parent = this.txt_prenom;
            this.txt_prenom.Size = new System.Drawing.Size(226, 39);
            this.txt_prenom.TabIndex = 2;
            this.txt_prenom.TextOffset = new System.Drawing.Point(5, 0);
            // 
            // UpdateInfo_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(47)))), ((int)(((byte)(50)))));
            this.ClientSize = new System.Drawing.Size(749, 736);
            this.Controls.Add(this.siticoneVSeparator1);
            this.Controls.Add(this.btn_Minimize);
            this.Controls.Add(this.btn_Exit);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.siticoneSeparator3);
            this.Controls.Add(this.siticoneSeparator2);
            this.Controls.Add(this.siticoneSeparator1);
            this.Controls.Add(this.btn_save);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.siticoneButton3);
            this.Controls.Add(this.siticoneButton1);
            this.Controls.Add(this.txt_instagram);
            this.Controls.Add(this.txt_twitter);
            this.Controls.Add(this.txt_linkeden);
            this.Controls.Add(this.txt_whatsapp);
            this.Controls.Add(this.txt_facebook);
            this.Controls.Add(this.txt_tel);
            this.Controls.Add(this.txt_adresse);
            this.Controls.Add(this.txt_ville);
            this.Controls.Add(this.txt_email);
            this.Controls.Add(this.txt_prenom);
            this.Controls.Add(this.text_nom);
            this.Controls.Add(this.txt_username);
            this.Controls.Add(this.panel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "UpdateInfo_Form";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "11";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.UpdateInfo_Form_FormClosing);
            this.Load += new System.EventHandler(this.UpdateInfo_Form_Load);
            this.Click += new System.EventHandler(this.UpdateInfo_Form_Click);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Siticone.UI.WinForms.SiticoneElipse siticoneElipse1;
        private Siticone.UI.WinForms.SiticoneMaterialTextBox txt_username;
        private Siticone.UI.WinForms.SiticoneMaterialTextBox txt_facebook;
        private Siticone.UI.WinForms.SiticoneMaterialTextBox txt_tel;
        private Siticone.UI.WinForms.SiticoneButton siticoneButton1;
        private Siticone.UI.WinForms.SiticoneMaterialTextBox txt_instagram;
        private Siticone.UI.WinForms.SiticoneMaterialTextBox txt_twitter;
        private Siticone.UI.WinForms.SiticoneMaterialTextBox txt_linkeden;
        private Siticone.UI.WinForms.SiticoneMaterialTextBox txt_whatsapp;
        private Siticone.UI.WinForms.SiticoneMaterialTextBox txt_adresse;
        private Siticone.UI.WinForms.SiticoneMaterialTextBox txt_ville;
        private Siticone.UI.WinForms.SiticoneMaterialTextBox txt_email;
        private System.Windows.Forms.Panel panel1;
        private Siticone.UI.WinForms.SiticoneButton siticoneButton3;
        private Siticone.UI.WinForms.SiticoneSeparator siticoneSeparator3;
        private Siticone.UI.WinForms.SiticoneSeparator siticoneSeparator2;
        private Siticone.UI.WinForms.SiticoneSeparator siticoneSeparator1;
        private Siticone.UI.WinForms.SiticoneButton btn_save;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_Minimize;
        private System.Windows.Forms.Button btn_Exit;
        private Siticone.UI.WinForms.SiticoneVSeparator siticoneVSeparator1;
        private System.Windows.Forms.Panel panel2;
        private Siticone.UI.WinForms.SiticoneMaterialTextBox txt_prenom;
        private Siticone.UI.WinForms.SiticoneMaterialTextBox text_nom;
    }
}